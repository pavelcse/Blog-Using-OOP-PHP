<?php
define("DB_HOST", "localhost");
define("DB_USER", "backbenc_pavel");
define("DB_PASS", "me.p@vel007");
define("DB_NAME", "backbenc_blog");

define("TITLE", "Pavel Parvej");

define("KEYWORD", "HTML Tutorials, CSS Tutorials, PHP Tutorials, JavaScript Tutorials, Java Tutorials, C++ Tutorials, Android Tutorials");
define("DESCRIPTION", "It is a website about Education, Progrannibg, General Knowledge, Historical Place, Tourist Place and so on.");

